"""Preparação local das linhas 11–15; executar com servidor parado."""
import copy
import json
from pathlib import Path

from PIL import Image, ImageDraw
from paleographia.config import load_config
from paleographia.data import require_valid
from paleographia.io import sha256, write_json, write_jsonl
from paleographia.recognition import recognize_lines
from paleographia.segmentation import crop_line
from paleographia.services import ReviewService

root = Path(__file__).resolve().parents[3]
out = Path(__file__).resolve().parent
service = ReviewService(root, load_config(root / 'configs/traslado_269r.toml'))
before = service.state()
assert before['revision'] == '20261016T191833_79606a37', 'Revisão alterada; reavaliar antes de preparar.'
assert len(before['lines']) == 10 and all(l['review_status'] == 'validated' for l in before['lines'])
page = before['pages'][0]
assert sha256(root / page['source_image']) == page['source_sha256']
assert page['transcribed_coverage'][1]['complete'] is True
write_json(out / 'estado_anterior.json', before)
region = 'body_11_15'
boxes = [[85, 1062, 1060, 1141], [85, 1117, 1060, 1194],
         [85, 1167, 1060, 1244], [85, 1211, 1060, 1292],
         [85, 1262, 1060, 1335]]
edition = json.loads((root / 'docs/revisao_humana/traslado_269r/comparacao.json').read_text(encoding='utf-8'))
source = page['transcribed_coverage'][1]['reference_source']
new_lines = []
for number, box in enumerate(boxes, 11):
    line = crop_line(page, box, number - 1, region, out, root,
                    'manual_candidate', 'manual_candidate_269r_11_15_20261016')
    line.update(line_id=f'l_traslado_269r_body_{number:02d}', comparison_line=number,
                reference_source=source, reference_pages=[2],
                published_reference={'text': edition['body_lines'][number-1]['published_text'],
                    'reference_source': source, 'reference_pages': [2],
                    'note': 'Edição publicada de apoio. Correspondência e leitura desta linha ainda pendentes de conferência humana.'})
    new_lines.append(line)
state = copy.deepcopy(before)
state['pages'][0]['transcribed_coverage'].append({
    'region_id': region, 'bbox_xyxy': [85, 1062, 1060, 1335],
    'reference_source': source, 'reference_pages': [2],
    'review_status': 'pending_review', 'complete': False,
    'reviewer': None, 'reviewed_at': None,
    'scope': 'Proposta das linhas 11–15 do corpo do 269r; recortes e cobertura aguardam conferência humana.'})
state['lines'].extend(new_lines)
require_valid(state['lines'], root, 'catalog', state['pages'])
write_jsonl(out / 'linhas_11_15.jsonl', new_lines)
preview = Image.new('RGB', (1005, 480), 'white')
draw = ImageDraw.Draw(preview)
for index, line in enumerate(new_lines):
    draw.text((5, index*96+5), str(index+11), fill='black')
    with Image.open(root / line['crop_image']) as crop:
        preview.paste(crop, (30, index*96))
preview.save(out / 'recortes_11_15.png')
try:
    predictions = recognize_lines(new_lines, service.recognizer, out / 'predictions.jsonl', root)
    assert len(predictions) == 5 and all(p['status'] == 'ok' and p['text_raw'].strip() for p in predictions)
    state['predictions'].extend(predictions)
    assert state['lines'][:10] == before['lines']
    assert state['predictions'][:-5] == before['predictions']
    assert state['pages'][0]['transcribed_coverage'][:2] == page['transcribed_coverage']
    assert all(l['text_diplomatic'] is None and l['review_status'] == 'pending_review'
               and l['geometry_status'] == 'pending_review' and l['reviewer'] is None for l in new_lines)
    assert service.state()['revision'] == before['revision'], 'Revisão concorrente; não salvar.'
    saved = service.save(state, 'prepare_269r_body_11_15_ppocrv6_pending_review')
    service.export(out / 'exportacao_preparada')
    write_json(out / 'verificacao.json', {'revision_before': before['revision'],
        'revision_after': saved['revision'], 'first_ten_unchanged': True,
        'previous_predictions_unchanged': True, 'previous_coverage_unchanged': True,
        'new_lines_pending': True, 'new_human_transcriptions_empty': True,
        'new_coverage_complete': False, 'recognition_count': 5,
        'metrics': None, 'reason': 'Sem referência humana validada nas novas linhas.'})
    print(json.dumps({'revision': saved['revision'], 'predictions': [p['text_raw'] for p in predictions]}, ensure_ascii=True))
finally:
    service.recognizer.close()
