import copy
import json
import urllib.request
from pathlib import Path

base = 'http://127.0.0.1:8011'
out = Path(__file__).resolve().parent
with urllib.request.urlopen(base + '/api/catalog') as response:
    state = json.load(response)
assert state['revision'] == '20261016T191633_f89a5b20'
assert len(state['lines']) == 10 and all(l['review_status'] == 'validated' for l in state['lines'])
(out / 'antes_cobertura.json').write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
coverage = copy.deepcopy(state['pages'][0]['transcribed_coverage'])
block = next(c for c in coverage if c['region_id'] == 'body_06_10')
block.update(complete=True, review_status='validated',
             scope='Cobertura completa confirmada pelo usuário somente para o bloco das linhas 6–10 do corpo do 269r.',
             confirmation_source='Mensagem explícita do usuário nesta conversa: Confirmo a cobertura completa somente do bloco das linhas 6 a 10.')
request = urllib.request.Request(base + '/api/pages/p_traslado_269r',
    data=json.dumps({'revision': state['revision'], 'changes': {'transcribed_coverage': coverage}}).encode('utf-8'),
    headers={'Content-Type': 'application/json'}, method='PATCH')
with urllib.request.urlopen(request) as response:
    saved_page = json.load(response)
assert saved_page['transcribed_coverage'][0] == state['pages'][0]['transcribed_coverage'][0]
with urllib.request.urlopen(base + '/api/catalog') as response:
    after = json.load(response)
assert after['lines'] == state['lines']
assert after['predictions'] == state['predictions']
(out / 'apos_cobertura.json').write_text(json.dumps(after, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps({'revision': after['revision'], 'coverage': after['pages'][0]['transcribed_coverage'][1]}, ensure_ascii=True))
